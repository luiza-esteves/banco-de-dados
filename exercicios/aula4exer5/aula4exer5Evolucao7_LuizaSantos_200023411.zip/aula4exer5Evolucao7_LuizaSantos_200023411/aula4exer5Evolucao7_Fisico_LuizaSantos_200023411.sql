-- --------  << aula4exer5Evolucao7 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 27/07/20222
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao7
--
-- Ultimas Alteracoes
--   27/07/2022 => Criação das tabelas
--   01/08/2022 => Alteração das tabelas inserindo engine e auto increment
--   			=> Alteração dos atributos telefone e cep para o tipo bigint
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
  IF NOT EXISTS aula4exer5Evolucao7;

USE aula4exer5Evolucao7;


-- TABELAS
CREATE TABLE IF NOT EXISTS MEDICO(
    nome varchar(30) NOT NULL,
    estado varchar(2) NOT NULL,
    numero INT NOT NULL,
   CONSTRAINT MEDICO_PK PRIMARY KEY(estado, numero)
)ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS ESPECIALIDADE(
    idEspecialidade INT NOT NULL AUTO_INCREMENT,
    nome varchar(30) NOT NULL,
   CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY(idEspecialidade)
)ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE IF NOT EXISTS possui(
    idEspecialidade INT NOT NULL,
    estado varchar(2) NOT NULL,
    numero INT NOT NULL,
   CONSTRAINT POSSUI_MEDICO_FK FOREIGN KEY(estado, numero) REFERENCES MEDICO(estado, numero),
   CONSTRAINT POSSUI_ESPECIALIDADE_FK FOREIGN KEY(idEspecialidade) REFERENCES ESPECIALIDADE(idEspecialidade) 
)ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS PACIENTE(
    sexo varchar(1) NOT NULL,
    dataNascimento date NOT NULL,
    nome varchar(30) NOT NULL,
    idPaciente INT NOT NULL auto_increment,
    rua varchar(30) NOT NULL,
    numero INT,
    bairro varchar(30) NOT NULL,
    complemento varchar(50),
    cidade varchar(30) NOT NULL,
    estado varchar(2) NOT NULL,
    cep BIGINT NOT NULL,
   CONSTRAINT PACIENTE_PK PRIMARY KEY(idPaciente)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS TELEFONE(
    idPaciente INT NOT NULL,
    telefone bigint NOT NULL,
    CONSTRAINT TELEFONE_PACIENTE_FK FOREIGN KEY(idPaciente) REFERENCES PACIENTE(idPaciente)
)ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS CONSULTA(
    dataConsulta date NOT NULL,
    horaConsulta time NOT NULL,
    localConsulta varchar(30) NOT NULL,
    idConsulta INT NOT NULL auto_increment,
    estado varchar(30) NOT NULL,
    numero INT NOT NULL,
    idPaciente INT NOT NULL,
   CONSTRAINT CONSULTA_PK PRIMARY KEY(idConsulta),
   CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY(estado, numero) REFERENCES MEDICO(estado, numero),
   CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY(idPaciente) REFERENCES PACIENTE(idPaciente)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS PRESCRICAO(
    idPrescricao INT NOT NULL auto_increment,
    dataEmissao date NOT NULL,
    idConsulta INT NOT NULL,
   CONSTRAINT PRESCRICAO_FK PRIMARY KEY(idPrescricao),
   CONSTRAINT PRESCRICAO_CONSULTA FOREIGN KEY(idConsulta) REFERENCES CONSULTA(idConsulta)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS MEDICAMENTO(
    idMedicamento INT NOT NULL auto_increment,
    principioAtivo varchar(30) NOT NULL,
   CONSTRAINT MEDICAMENTO_PK PRIMARY KEY(idMedicamento)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS contem(
    idPrescricao INT NOT NULL ,
    idMedicamento INT NOT NULL,
   CONSTRAINT CONTEM_PRESCRICAO_FK FOREIGN KEY(idPrescricao) REFERENCES PRESCRICAO(idPrescricao),
   CONSTRAINT CONTEM_MEDICAMENTO_FK FOREIGN KEY(idMedicamento) REFERENCES MEDICAMENTO(idMedicamento)
)ENGINE = InnoDB;