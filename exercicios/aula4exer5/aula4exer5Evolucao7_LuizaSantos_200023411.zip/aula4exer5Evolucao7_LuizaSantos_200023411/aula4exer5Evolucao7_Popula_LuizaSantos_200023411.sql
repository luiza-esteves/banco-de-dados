-- --------  << aula4exer5Evolucao7 >>  ----------
--
--                    SCRIPT DE INSERÇÃO DE DADOS (DML)
--
-- Data Criacao ...........: 27/07/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao7
--
-- Ultimas Alteracoes
--   01/08/2022 => Alteração dos dados nas inserções
-- 				=> Alteração na inserção, colocando, deixando os id's serem atribuitos automaticamente	
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao7;
INSERT INTO MEDICO
    ( nome, estado, numero)
VALUES
    ( 'Mariana Carvalho Queiroz', 'GO',967834),
    ( 'Ana Clara de Matos', 'SP',469244),
    ( 'Carlos Alberto Fonseca', 'DF', 970059),
    ( 'Júlia Marques Alves', 'RJ', 340099),
    ( 'Luciano Roberto Meireles', 'MG', 380026),
    ( 'Pedro Henrique dos Santos', 'DF', 120255)
    ;

INSERT INTO PACIENTE
    (sexo,dataNascimento,nome,rua,numero,bairro,complemento,cidade,estado,cep)
VALUES
    ('f', '2002-03-14', 'Vilma Barbosa da Silva', 'Rua 78', 43,'Lago Sul', 'Próximo ao Parque', 'Brasília', 'DF', 65789543),
    ('m', '1992-10-27', 'Marcos Paulo dos Santos', 'Rua São José', 22,'Setor Leste', 'Próximo ao Condomínio', 'Luziânia', 'GO', 72804302),
	('f', '1990-08-02', 'Maria Aparecida Meireles', 'Rua Bom Caminho', 12,'Lago Norte', 'Ao lado do Mercado Comper', 'Brasília', 'DF', 65783442),
    ('f', '1976-05-22', 'Eduarda Xavier Oliveira', 'Rua São Tome', 21,'Lago Sul', 'Ao lado do prédio São Pedro', 'Brasília', 'DF', 62383411),
    ('m', '1960-02-01', 'Felipe Salomão Mariano', 'Rua Evangelino Meireles', 75,'Setor Oeste', 'próximo Hospital Céu Azul', 'Valparaíso', 'GO', 23743419),
    ('f', '1999-12-23', 'Ana Júlia Alves', 'Rua Antonio Farias', 37,'Setor Sul', '´próximo a padaria', 'São Paulo', 'SP', 44723183)
;

INSERT INTO ESPECIALIDADE
    ( nome )
VALUES
    ('Cardiologista'),
    ('Pediatra'),
    ('Obstetra'),
    ('Ginecologista'),
    ('Dermatologista'),
    ('Psicólogo');
    
INSERT INTO possui
    (idEspecialidade,estado,numero)
VALUES
    (1, 'GO', 967834),
    (2, 'SP', 469244),
    (3, 'DF', 970059),
	(4, 'MG', 380026),
	(5, 'GO', 967834),
	(6, 'DF', 120255);

INSERT INTO MEDICAMENTO
    ( principioAtivo)
VALUES
    ( 'Anastrazol' ),
    ( 'Citarabina'),
    ( 'Amoxicilina'),
    ( 'Cetoconazol'),
    ( 'Aspirina'),
    ( 'Fenoterol')
    ;

INSERT INTO telefone
    (idPaciente, telefone)
VALUES
    (1,61998075453),
    (2,11990635412),
    (3,61982567290),
	(4,62992315692),
	(5,77992281221),
	(6,61989609772)
    ;
    
INSERT INTO CONSULTA
    ( dataConsulta, horaConsulta, localConsulta, estado,numero,idPaciente)
VALUES
    ('2021-03-28', '13:22:42', 'DF', 'GO',967834,1 ),
	('2022-05-11', '08:10:18', 'DF', 'SP',469244,2 ),
    ('2022-10-09', '16:02:38', 'DF', 'DF', 970059,3 ),
    ('2022-05-11', '09:11:12', 'DF',  'MG', 380026,4 ),
    ('2022-05-11', '07:20:01', 'DF', 'RJ', 340099,5 ),
    ('2022-05-11', '17:12:21', 'DF', 'DF', 120255,6 );

INSERT INTO PRESCRICAO
    ( dataEmissao, idConsulta )
VALUES
    ('2022-03-27', 1 ),
    ('2022-05-13', 2 ),
    ('2022-07-12', 3 ),
    ('2022-01-10', 4 ),
    ('2022-04-22', 5 ),
    ('2022-08-09', 6 );

INSERT INTO contem
    (idPrescricao, idMedicamento)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 6);
