-- --------  << Clínica Médica>>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 20/07/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdClinicaMedica
--
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

 CREATE DATABASE bdClinicaMedica;
 USE bdClinicaMedica;

CREATE TABLE PACIENTE (
    idPaciente INT NOT NULL AUTO_INCREMENT,
    nomeCompleto VARCHAR(50) NOT NULL,
    sexo ENUM('m','f') NOT NULL,
    rua VARCHAR(20) NOT NULL,
    cep INT NOT NULL,
    bairro VARCHAR(20) NOT NULL,
    quadra INT NOT NULL,

    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE telefone ( 
    telefone INT NOT NULL,
    idPaciente INT NOT NULL,

    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (idPaciente)
        REFERENCES PACIENTE (idPaciente)
) ;

CREATE TABLE MEDICO (
    numCrm INT NOT NULL,
    estadoCrm VARCHAR(2) NOT NULL,
    nomeCompleto VARCHAR(30) NOT NULL,

    CONSTRAINT MEDICO_PK PRIMARY KEY(numCrm, estadoCrm)
);

CREATE TABLE ESPECIALIDADE (
    idEspecialidade INT NOT NULL AUTO_INCREMENT,
    nomeEspecialidade VARCHAR(20) NOT NULL,

    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY(idEspecialidade)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE MEDICAMENTO (
    idMedicamento INT NOT NULL AUTO_INCREMENT,
    nomeCientifico VARCHAR(30) NOT NULL,
    nomeComercial VARCHAR(30) NOT NULL,
    posologia VARCHAR(40) NOT NULL,

    CONSTRAINT MEDICO_PK PRIMARY KEY (idEspecialidade)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE CONSULTA(
    idConsulta INT NOT NULL AUTO_INCREMENT,
    numCrm INT NOT NULL,
    estadoCrm VARCHAR(2) NOT NULL,
    idPaciente INT NOT NULL,
    data DATE NOT NULL,
    hora TIME NOT NULL,
    local VARCHAR(30) NOT NULL,

    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (numCrm,estadoCrm)
        REFERENCES MEDICO (numCrm,estadoCrm),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente)
        REFERENCES PACIENTE (idPaciente)
 )ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE RECEITA (
    idReceita INT NOT NULL AUTO_INCREMENT,
    dataEmissao DATE NOT NULL,
    idConsulta INT NOT NULL,

    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA FOREIGN KEY (idConsulta)
        REFERENCES CONSULTA_consulta(idConsulta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE possui_especialidade (
    idEspecialidade INT NOT NULL,
    numCrm INT NOT NULL,
    estadoCrm VARCHAR(2) NOT NULL,
    
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (numCrm,estadoCrm)
        REFERENCES MEDICO (numCrm,estadoCrm),
    CONSTRAINT possui_ESPECIALIDADE FOREIGN KEY (idEspecialidade)
        REFERENCES ESPECIALIDADE (idEspecialidade)
);

CREATE TABLE contem (
    idReceita INT NOT NULL,
    idMedicamento INT NOT NULL,

    CONSTRAINT contem_RECEITA_FK FOREIGN KEY (idReceita)
        REFERENCES RECEITA (idReceita),
    CONSTRAINT contem_FARMACO_PK FOREIGN KEY (idMedicamento)
        REFERENCES MEDICAMENTO (idMedicamento)    
);

