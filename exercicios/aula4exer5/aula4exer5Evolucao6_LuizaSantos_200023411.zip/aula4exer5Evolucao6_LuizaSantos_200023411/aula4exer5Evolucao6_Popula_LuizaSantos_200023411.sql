-- --------  << aula4exer5Evolucao6Popula >>  ----------
--
--                    SCRIPT DE POPULAR (DML)
--
-- Data Criacao ...........: 27/07/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6Popula
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao6Fisico;


INSERT INTO MEDICO
    ( nome, estado, numero)
VALUES
    ( 'Mariana Carvalho Queiroz', 'GO',967834),
    ( 'Ana Clara de Matos', 'SP',469244),
    ( 'Carlos Alberto Fonseca', 'DF', 970059);

INSERT INTO PACIENTE
    (sexo,dataNascimento,nome,rua,numero,bairro,complemento,cidade,estado,cep)
VALUES
    ('f', '2002-03-14', 'Vilma Barbosa da Silva', 'Rua 78', 43,'Lago Sul', 'Próximo ao Parque', 'Brasília', 'DF', 65789543),
    ('m', '1992-10-27', 'Marcos Paulo dos Santos', 'Rua São José', 22,'Setor Leste', 'Próximo ao Condomínio', 'Luziânia', 'GO', 72804302),
	('f', '1990-08-02', 'Maria Aparecida Meireles', 'Rua Bom Caminho', 12,'Lago Norte', 'Ao lado do Mercado Comper', 'Brasília', 'DF', 65783442)
;

INSERT INTO ESPECIALIDADE
    ( nome )
VALUES
    ('Cardiologista'),
    ('Pediatra'),
    ('Psicólogo');
    
INSERT INTO possui
    (idEspecialidade,estado,numero)
VALUES
    (1, 'GO', 967834),
    (2, 'SP', 469244),
    (3, 'DF', 970059);

INSERT INTO MEDICAMENTO
    ( principioAtivo,nomeCientifico,nomeComercial)
VALUES
    ( 'Anastrazol','Anastrolibbs','Arimidex' ),
    ( 'Citarabina','Aracytin','Citarabina'),
    ( 'Amoxicilina','Amoxil','Amoxilina');

INSERT INTO telefone
    (idPaciente, telefone)
VALUES
    (1,619980754),
    (2,119906354),
    (3,619825672);
    
INSERT INTO CONSULTA
    ( dataConsulta, horaConsulta, localConsulta, estado,numero,idPaciente)
VALUES
    ('2021-03-28', '13:22:42', 'DF', 'GO',967834,1 ),
	('2022-05-11', '08:10:18', 'DF', 'SP',469244,2 ),
    ('2022-10-09', '16:02:38', 'DF', 'DF', 970059,3 );

INSERT INTO PRESCRICAO
    ( dataEmissao, idConsulta )
VALUES
    ('2022-03-27', 1 ),
    ('2022-05-13', 2 ),
    ('2022-08-08', 3 );

INSERT INTO contem
    (idPrescricao, idMedicamento)
VALUES
    (1, 1),
    (2, 2),
    (3, 3);

