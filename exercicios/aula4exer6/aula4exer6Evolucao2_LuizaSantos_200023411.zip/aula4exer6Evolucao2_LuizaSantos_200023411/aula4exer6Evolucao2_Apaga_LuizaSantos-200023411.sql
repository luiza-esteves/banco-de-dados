-- --------  << aula4exer6Evolucao2 >>  ----------
--
--                    SCRIPT DE EXCLUSÃO (DDL)
--
-- Data Criacao ...........: 01/08/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao2;

DROP TABLE INFRACAO;

DROP TABLE AGENTE;

DROP TABLE LOCALI;

DROP TABLE VEICULO;

DROP TABLE MODELO;

DROP TABLE TIPOINFRACAO;

DROP TABLE CATEGORIA;

DROP TABLE PROPRIETARIO;
