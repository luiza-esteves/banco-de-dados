-- --------  << aula4exer6Evolucao2 >>  ----------
--
--                    SCRIPT DE INSERÇÃO DE DADOS (DML)
--
-- Data Criacao ...........: 01/08/2022
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao2;

INSERT INTO PROPRIETARIO
    (cpf, nomeCompleto,bairro,cidade,estado,dtNascimento,sexo)
VALUES
    ( 12345678901, 'Ana Clara de Matos','Setor Leste','Luziânia','Goiás','2002-05-11','f'),
    ( 07895437611, 'Gabriel Sabanai','Asa Sul','Brasília','Distrito Federal','1980-11-08','m'),
    ( 98702479203, 'João Victor Batista','Asa Norte','Brasília','Distrito Federal','2000-10-21','m');

INSERT INTO CATEGORIA
    (dsCategoria)
VALUES
('AUTOMÓVEL'),
('MOTOCICLETA'),
('CAMINHÃO');

INSERT INTO TIPOINFRACAO
    (dsInfracao,valorInfracao)
VALUES
('AVANÇO DE SINAL VERMELHO',1200.50),
('PARADA SOBRE FAIXA DE PEDESTRES',800.98),
('ESTACIONAMENTO INDEVIDO',987.34);

INSERT INTO MODELO
    (dsModelo)
VALUES
('GOL MI'),
('GOL 1.8'),
('UNO CS');
 
    
INSERT INTO VEICULO
    (placa,chassi,corPredominante,codigoModelo,codigoCategoria,anoFabricacao,cpfProprietario)
VALUES
('HUI8766','4BRKJHUIOP2189045','VERMELHO',100000,10,2001,12345678901),
('MTY5023','5BRLYVBADX4583645','PRETO',100001,11,1980,07895437611),
('XKL6507','6BRKLNCIOP2183072','PRATA',100002,12,2012,98702479203);

INSERT INTO LOCALI
    (latitude,longitude,velocidadePermitida)
VALUES
(3.56,8.98,80.00),
(8.32,6.45,60.00),
(7.67,3.50,70.00);

INSERT INTO AGENTE
    (matricula,nomeCompleto,dtContratacao)
VALUES
(897,'Mariele Ataíde Braz','1980-11-08'),
(363,'Carlos Vítor Carneiro','1975-02-12'),
(424,'João Marques Silvéria','1967-04-03');
    
INSERT INTO INFRACAO
    (dtInfracao,horaInfracao,velocidadeAferida,placa,matricula,codigoLocal,codigoTipo)
VALUES
('2011-11-08','11:23:08',120.98,'HUI8766',897,1,1),
('2015-09-22','09:43:28',134.45,'MTY5023',363,2,2),
('2018-10-19','02:45:46',99.93,'XKL6507',424,3,3);
    
