-- --------  << aula4exer6Evolucao2 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/08/20222
-- Autor(es) ..............: Luíza Esteves dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--

--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
  IF NOT EXISTS aula4exer6Evolucao2;

USE aula4exer6Evolucao2;


-- TABELAS
CREATE TABLE IF NOT EXISTS PROPRIETARIO(
    cpf BIGINT NOT NULL,
    nomeCompleto varchar(50) NOT NULL,
    bairro varchar(20) NOT NULL,
    cidade varchar(30) NOT NULL,
    estado varchar(30) NOT NULL,
    dtNascimento date NOT NULL,
    sexo char(1) NOT NULL,
   CONSTRAINT PROPRIETARIO_PK PRIMARY KEY(cpf)
)ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS CATEGORIA(
    codigoCategoria INT NOT NULL AUTO_INCREMENT,
    dsCategoria varchar(30) NOT NULL,
 
   CONSTRAINT CATEGORIA_PK PRIMARY KEY(codigoCategoria)
)ENGINE = InnoDB AUTO_INCREMENT = 10;

CREATE TABLE IF NOT EXISTS TIPOINFRACAO(
    codigoTipo INT NOT NULL AUTO_INCREMENT,
    dsInfracao varchar(50) NOT NULL,
    valorInfracao decimal(4.2),
 
   CONSTRAINT TIPOINFRACAO_PK PRIMARY KEY(codigoTipo)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS MODELO(
    codigoModelo INT NOT NULL AUTO_INCREMENT,
    dsModelo varchar(30) NOT NULL,
 
   CONSTRAINT MODELO_PK PRIMARY KEY(codigoModelo)
)ENGINE = InnoDB AUTO_INCREMENT = 100000;

CREATE TABLE IF NOT EXISTS VEICULO(
    placa varchar(7) NOT NULL,
    chassi varchar(17) NOT NULL,
    corPredominante VARCHAR(30) NOT NULL,
    codigoModelo INT NOT NULL,
    codigoCategoria int NOT NULL,
    anoFabricacao int NOT NULL,
    cpfProprietario bigint NOT NULL,
   CONSTRAINT VEICULO_PK PRIMARY KEY(placa),
   CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY(cpfProprietario) REFERENCES PROPRIETARIO(cpf),
   CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY(codigoModelo) REFERENCES MODELO(codigoModelo),
   CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY(codigoCategoria) REFERENCES CATEGORIA(codigoCategoria)
)ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS LOCALI(
    codigoLocal INT NOT NULL AUTO_INCREMENT,
    latitude decimal(3.2) NOT NULL,
    longitude decimal(3.2) NOT NULL,
    velocidadePermitida decimal(4.2) NOT NULL,
 
   CONSTRAINT LOCAL_PK PRIMARY KEY(codigoLocal)
)ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS AGENTE(
    matricula INT NOT NULL,
    nomeCompleto varchar(30) NOT NULL,
    dtContratacao date NOT NULL,
 
   CONSTRAINT AGENTE_PK PRIMARY KEY(matricula)
)ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS INFRACAO(
    codigoInfracao INT NOT NULL auto_increment,
    dtInfracao date NOT NULL,
    horaInfracao time NOT NULL,
    velocidadeAferida decimal(4.2) NOT NULL,
	placa varchar(7) NOT NULL,
    matricula INT NOT NULL,
    codigoLocal int NOT NULL,
    codigoTipo INT NOT NULL,
   CONSTRAINT INFRACAO_PK PRIMARY KEY(codigoInfracao),
   CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY(placa) REFERENCES VEICULO(placa),
   CONSTRAINT INFRACAO_AGENTE_FK FOREIGN KEY(matricula) REFERENCES AGENTE(matricula),
   CONSTRAINT INFRACAO_LOCAL_FK FOREIGN KEY(codigoLocal) REFERENCES LOCALI(codigoLocal),
   CONSTRAINT INFRACAO_TIPOINFRACAO_FK FOREIGN KEY(codigoTipo) REFERENCES TIPOINFRACAO(codigoTipo)
)ENGINE = InnoDB;





